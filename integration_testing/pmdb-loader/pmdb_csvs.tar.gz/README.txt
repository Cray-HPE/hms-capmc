// Copyright 2020 Hewlett Packard Enterprise Development LP

This file contains information on the data contained in the pmdb_csvs.tar.gz
files, how and where they were captured, and what is being done with them.

This data was captured for the purpose of creating a small integration test
system where capmc power and energy commands can work against a database of real
data to insure correct operation.  There is enough data to verify the queries
can operate correctly, the formats haven't changed, and nothing has been
modified in the 'hms/hms-postgresql' service that will break the usage of capmc.

This data was captured from Gamora (gamora-ncn-w001) on Jan 9, 2020 from 10am to
10:30am CDT.  It represents the telemetry data streamed from both the moutain
and river hardware during this time.  Data from some of the mountain nodes was
discarded as redundant to save space in the test database.

This data was modified to set the river node x300c0s19b4 to have a
physical_context of 7 instead of 6 for Power information. 7 maps to
PowerSupplyBay which mactches the HPE Proliant server PMDB phsyical_context.

The following files are contained in this package:

cc_data.csv - mountain cabinet telemetry data
nc_data.csv - mountain node telemetry data
sc_data.csv - mountain switch telemetry data
river_data.csv - all river telemetry data
sensor_types.csv - values for sensor field data
parental_contexts.csv - values for parental context field data
physical_contexts.csv - values for physical contect field data
physical_sub_contexts.csv - values for phyical sub context field data
version.csv - values for the database version information

For River telemetry data, we have the following xnames reporting information:
Note: these are node controllers, not nodes.  That causes some problems with
the functions that ask for per/nid breakdown...
river_view:
   location   | count
--------------+-------
 x3000c0s19b4 |  5940
 x3000c0s19b1 |  5939
 x3000c0s19b3 |  5940
 x3000c0s19b2 |  5940

 sensor_type | count
-------------+-------
 Power       |   720
 Temperature | 20160
 Voltage     |  2879

Mountain telemetry data has the following entries in each table.
nc_view:
   location    | count
---------------+--------
 x5000c1s0b0   |  12521
 x5000c1s0b0n0 | 243263
 x5000c1s0b0n1 | 243253
 x5000c1s0b1   |  12521
 x5000c1s0b1n0 | 243267
 x5000c1s0b1n1 | 243266
 x5000c1s1b0   |  12510
 x5000c1s1b0n0 | 243092
 x5000c1s1b0n1 | 243093
 x5000c1s1b1   |  12531
 x5000c1s1b1n0 | 243498
 x5000c1s1b1n1 | 243500

 sensor_type | count
-------------+--------
 Current     | 465084
 Energy      |  42933
 Power       | 422185
 Temperature | 393531
 Voltage     | 672582

cc_view:
 location | count
----------+--------
 x5000c1  | 132760
 x5000c3  | 133056

 sensor_type | count
-------------+--------
 Current     |  75600
 Power       |  28800
 Pressure    |   7056
 Temperature |  35560
 Voltage     | 118800

sc_view:
  location   | count
-------------+--------
 x5000c1r1b0 | 157600
 x5000c1r3b0 | 159149
 x5000c1r5b0 | 120840
 x5000c1r7b0 | 154200

 sensor_type | count
-------------+--------
 Current     | 163540
 Power       |  48295
 Temperature | 163680
 Voltage     | 216274

Together these files can create a working, fully populated telemetry database
for use in the capmc integration tests.

In addition to the database files, the following system information files are
also included to capture the hardware information from Gamora at the time
the telemetry data was captured.  The state components data is used in the
synthetic hsm to provide consistent data capmc needs to query the telemetry
database.

ComponentEndpoints.json - result of 'cray hsm Inventory ComponentEndpoints list'
RedfishEndpoints.json - result of 'cray hsm Inventory RedfishEndpoints list'
StateComponents.json - result of 'cray hsm State Components list'


